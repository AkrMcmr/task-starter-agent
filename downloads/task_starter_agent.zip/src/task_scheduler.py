#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Scheduler for Task Starter Agent
This module handles scheduling of notifications at specific times of day.
"""

import os
import logging
import schedule
import time
import threading
from datetime import datetime, timedelta

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class TaskScheduler:
    """
    Class to handle scheduling of task notifications
    """
    
    def __init__(self, line_bot_api=None, task_analyzer=None, obsidian_connector=None):
        """
        Initialize the task scheduler
        
        Args:
            line_bot_api (LineBotApi): LINE Bot API instance
            task_analyzer (TaskAnalyzer): Task analyzer instance
            obsidian_connector (ObsidianConnector): Obsidian connector instance
        """
        self.line_bot_api = line_bot_api
        self.task_analyzer = task_analyzer
        self.obsidian_connector = obsidian_connector
        self.user_ids = []  # List of user IDs to notify
        
        # Default notification times
        self.morning_time = "07:00"
        self.afternoon_time = "13:00"
        self.evening_time = "22:00"
        
        # Load user IDs from environment or config
        self._load_user_ids()
    
    def _load_user_ids(self):
        """
        Load user IDs from environment variable or config file
        """
        user_ids_env = os.environ.get('LINE_USER_IDS', '')
        if user_ids_env:
            self.user_ids = user_ids_env.split(',')
        
        if not self.user_ids:
            logger.warning("No user IDs configured for notifications")
    
    def set_notification_times(self, morning=None, afternoon=None, evening=None):
        """
        Set notification times
        
        Args:
            morning (str): Morning notification time (HH:MM)
            afternoon (str): Afternoon notification time (HH:MM)
            evening (str): Evening notification time (HH:MM)
        """
        if morning:
            self.morning_time = morning
        if afternoon:
            self.afternoon_time = afternoon
        if evening:
            self.evening_time = evening
    
    def add_user_id(self, user_id):
        """
        Add a user ID to the notification list
        
        Args:
            user_id (str): LINE user ID
        """
        if user_id not in self.user_ids:
            self.user_ids.append(user_id)
            logger.info(f"Added user ID {user_id} to notification list")
    
    def remove_user_id(self, user_id):
        """
        Remove a user ID from the notification list
        
        Args:
            user_id (str): LINE user ID
        """
        if user_id in self.user_ids:
            self.user_ids.remove(user_id)
            logger.info(f"Removed user ID {user_id} from notification list")
    
    def send_morning_notification(self):
        """
        Send morning notification to all users
        """
        if not self.line_bot_api or not self.task_analyzer:
            logger.error("LINE Bot API or Task Analyzer not initialized")
            return
        
        logger.info("Sending morning notifications")
        
        # Get morning message and routine
        message = self.task_analyzer.get_time_appropriate_message()
        routine = self.task_analyzer.get_morning_routine()
        
        # Get priority tasks
        priority_tasks = []
        if self.obsidian_connector:
            todos = self.obsidian_connector.get_incomplete_todos()
            priority_todos = self.obsidian_connector.get_todos_by_priority(todos)
            priority_tasks = priority_todos[:3]
        
        # Format tasks for display
        formatted_tasks = []
        for task in priority_tasks:
            formatted_task = self.task_analyzer.format_task_for_message(task)
            formatted_tasks.append(formatted_task)
        
        # Create notification message
        notification = f"{message}\n\n【朝のルーティン】\n"
        for i, step in enumerate(routine, 1):
            notification += f"{i}. {step}\n"
        
        notification += "\n【今日の優先タスク】\n"
        for i, task in enumerate(formatted_tasks, 1):
            notification += f"{i}. {task['title']} - {task['first_step']}\n"
        
        notification += "\n準備ができたら「今日のタスク」と送ってください。"
        
        # Send to all users
        for user_id in self.user_ids:
            try:
                self.line_bot_api.push_message(
                    user_id,
                    TextSendMessage(text=notification)
                )
                logger.info(f"Sent morning notification to user {user_id}")
            except Exception as e:
                logger.error(f"Error sending morning notification to user {user_id}: {e}")
    
    def send_afternoon_notification(self):
        """
        Send afternoon notification to all users
        """
        if not self.line_bot_api or not self.task_analyzer:
            logger.error("LINE Bot API or Task Analyzer not initialized")
            return
        
        logger.info("Sending afternoon notifications")
        
        # Get afternoon message
        message = self.task_analyzer.get_time_appropriate_message()
        
        # Get priority tasks
        priority_tasks = []
        if self.obsidian_connector:
            todos = self.obsidian_connector.get_incomplete_todos()
            priority_todos = self.obsidian_connector.get_todos_by_priority(todos)
            priority_tasks = priority_todos[:3]
        
        # Create notification message
        notification = f"{message}\n\n【午後の優先タスク】\n"
        
        for i, task in enumerate(priority_tasks, 1):
            first_steps = self.task_analyzer.get_first_steps(task)
            first_step = first_steps[0] if first_steps else "内容を確認する"
            notification += f"{i}. {task['text']} - {first_step}\n"
        
        notification += "\n次のタスクを確認するには「次のステップ」と送ってください。"
        
        # Send to all users
        for user_id in self.user_ids:
            try:
                self.line_bot_api.push_message(
                    user_id,
                    TextSendMessage(text=notification)
                )
                logger.info(f"Sent afternoon notification to user {user_id}")
            except Exception as e:
                logger.error(f"Error sending afternoon notification to user {user_id}: {e}")
    
    def send_evening_notification(self):
        """
        Send evening notification to all users
        """
        if not self.line_bot_api or not self.task_analyzer:
            logger.error("LINE Bot API or Task Analyzer not initialized")
            return
        
        logger.info("Sending evening notifications")
        
        # Get evening message
        message = self.task_analyzer.get_time_appropriate_message()
        
        # Get completed and incomplete tasks
        completed_tasks = []
        incomplete_tasks = []
        
        if self.obsidian_connector:
            all_todos = self.obsidian_connector.get_all_todos()
            completed_tasks = [todo for todo in all_todos if todo['completed']]
            incomplete_tasks = [todo for todo in all_todos if not todo['completed']]
            
            # Sort incomplete tasks by priority for tomorrow
            incomplete_tasks = self.obsidian_connector.get_todos_by_priority(incomplete_tasks)
        
        # Create notification message
        notification = f"{message}\n\n"
        
        if completed_tasks:
            notification += "【今日完了したタスク】\n"
            for i, task in enumerate(completed_tasks[:3], 1):
                notification += f"{i}. {task['text']}\n"
            notification += "\nお疲れ様でした！\n\n"
        
        if incomplete_tasks:
            notification += "【明日の優先タスク】\n"
            for i, task in enumerate(incomplete_tasks[:3], 1):
                first_steps = self.task_analyzer.get_first_steps(task)
                first_step = first_steps[0] if first_steps else "内容を確認する"
                notification += f"{i}. {task['text']} - {first_step}\n"
        
        notification += "\n明日も一緒に頑張りましょう！"
        
        # Send to all users
        for user_id in self.user_ids:
            try:
                self.line_bot_api.push_message(
                    user_id,
                    TextSendMessage(text=notification)
                )
                logger.info(f"Sent evening notification to user {user_id}")
            except Exception as e:
                logger.error(f"Error sending evening notification to user {user_id}: {e}")
    
    def schedule_notifications(self):
        """
        Schedule all notifications
        """
        logger.info("Scheduling notifications")
        logger.info(f"Morning time: {self.morning_time}")
        logger.info(f"Afternoon time: {self.afternoon_time}")
        logger.info(f"Evening time: {self.evening_time}")
        
        # Schedule morning notification
        schedule.every().day.at(self.morning_time).do(self.send_morning_notification)
        
        # Schedule afternoon notification
        schedule.every().day.at(self.afternoon_time).do(self.send_afternoon_notification)
        
        # Schedule evening notification
        schedule.every().day.at(self.evening_time).do(self.send_evening_notification)
    
    def run_scheduler(self):
        """
        Run the scheduler in a separate thread
        """
        self.schedule_notifications()
        
        def run_schedule():
            while True:
                schedule.run_pending()
                time.sleep(60)  # Check every minute
        
        # Start scheduler in a separate thread
        scheduler_thread = threading.Thread(target=run_schedule)
        scheduler_thread.daemon = True
        scheduler_thread.start()
        
        logger.info("Scheduler started")

if __name__ == "__main__":
    # This is for testing
    from linebot import LineBotApi
    from task_analyzer import TaskAnalyzer
    from obsidian_connector import ObsidianConnector
    
    # Initialize components
    line_bot_api = LineBotApi(os.environ.get('LINE_CHANNEL_ACCESS_TOKEN', ''))
    obsidian_connector = ObsidianConnector()
    task_analyzer = TaskAnalyzer(obsidian_connector)
    
    # Initialize scheduler
    scheduler = TaskScheduler(line_bot_api, task_analyzer, obsidian_connector)
    
    # Add test user ID
    test_user_id = os.environ.get('LINE_TEST_USER_ID', '')
    if test_user_id:
        scheduler.add_user_id(test_user_id)
    
    # Set notification times for testing
    current_time = datetime.now()
    test_time = (current_time + timedelta(minutes=1)).strftime("%H:%M")
    scheduler.set_notification_times(morning=test_time)
    
    # Run scheduler
    scheduler.run_scheduler()
    
    # Keep the script running
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("Scheduler stopped")
