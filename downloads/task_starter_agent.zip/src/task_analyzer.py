#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Task Analyzer for Task Starter Agent
This module analyzes tasks and provides recommendations for starting work.
"""

import os
import re
import json
import logging
import random
from datetime import datetime, time, timedelta

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class TaskAnalyzer:
    """
    Class to analyze tasks and provide recommendations
    """
    
    def __init__(self, obsidian_connector=None):
        """
        Initialize the task analyzer
        
        Args:
            obsidian_connector (ObsidianConnector): Connector to Obsidian
        """
        self.obsidian_connector = obsidian_connector
        
        # Task categories and their typical first steps
        self.task_categories = {
            'communication': {
                'keywords': ['連絡', 'メール', '電話', 'コンタクト', '問い合わせ'],
                'first_steps': [
                    "連絡する相手と内容を確認する",
                    "必要な情報を整理する",
                    "連絡手段を選択する（メール/電話/チャット）"
                ]
            },
            'document': {
                'keywords': ['書', 'レポート', '文書', '資料', '見積書', '報告'],
                'first_steps': [
                    "必要な情報を集める",
                    "目次や構成を考える",
                    "参考資料を確認する"
                ]
            },
            'development': {
                'keywords': ['構築', '開発', 'アプリ', 'サイト', 'ホームページ', 'コード'],
                'first_steps': [
                    "要件を整理する",
                    "必要な技術や資料を確認する",
                    "開発環境を準備する"
                ]
            },
            'shopping': {
                'keywords': ['買い物', '購入', 'ショッピング', '注文'],
                'first_steps': [
                    "必要なものリストを作成する",
                    "予算を確認する",
                    "購入先を調査する"
                ]
            },
            'cleaning': {
                'keywords': ['掃除', '片付け', '整理', '処分'],
                'first_steps': [
                    "5分だけ始めてみる",
                    "片付ける場所を決める",
                    "必要なものと不要なものを分ける"
                ]
            },
            'learning': {
                'keywords': ['勉強', '学習', '習得', 'ドイツ語', '英語', '講座'],
                'first_steps': [
                    "学習内容を確認する",
                    "5分だけ始めてみる",
                    "学習リソースを準備する"
                ]
            },
            'planning': {
                'keywords': ['計画', '予定', 'スケジュール', '段取り'],
                'first_steps': [
                    "目標を明確にする",
                    "必要なステップをリストアップする",
                    "タイムラインを設定する"
                ]
            }
        }
        
        # Motivational messages for different times of day
        self.morning_messages = [
            "おはようございます！今日も素晴らしい一日になりますように。まずは簡単なタスクから始めましょう。",
            "新しい朝の始まりです。今日のタスクに取り組む前に、深呼吸して心を落ち着かせましょう。",
            "おはようございます！ベッドから出て、水を一杯飲むところから始めましょう。",
            "今日という日は二度と来ません。まずは小さな一歩から始めて、充実した一日にしましょう。",
            "おはようございます！朝の光を浴びて、今日の最初のタスクに取り組む準備をしましょう。"
        ]
        
        self.afternoon_messages = [
            "お昼休みが終わりました。午後の作業を始める前に、今日の残りのタスクを確認しましょう。",
            "午後のエネルギー充電完了！次のタスクに取り組む準備はできていますか？",
            "お昼休み明けは集中力が低下しがちです。まずは簡単なタスクから再開しましょう。",
            "午後の作業開始です。残りのタスクを確認して、優先順位を付け直しましょう。",
            "お昼休み後の新たなスタートです。次のタスクに5分だけ取り組んでみましょう。"
        ]
        
        self.evening_messages = [
            "一日お疲れ様でした。寝る前に明日の準備をしておくと、朝がスムーズに始まります。",
            "今日も一日お疲れ様でした。明日のタスクを確認して、心の準備をしておきましょう。",
            "一日の終わりです。今日の成果を振り返り、明日の計画を立てましょう。",
            "おやすみ前のひととき。明日の最初のタスクを決めておくと、朝の出だしがスムーズになります。",
            "今日も一日お疲れ様でした。明日の最初のタスクを決めて、気持ちよく眠りにつきましょう。"
        ]
    
    def get_time_appropriate_message(self):
        """
        Get a message appropriate for the current time of day
        
        Returns:
            str: Time-appropriate message
        """
        now = datetime.now()
        current_hour = now.hour
        
        if 5 <= current_hour < 12:
            return random.choice(self.morning_messages)
        elif 12 <= current_hour < 18:
            return random.choice(self.afternoon_messages)
        else:
            return random.choice(self.evening_messages)
    
    def categorize_task(self, task_text):
        """
        Categorize a task based on its text
        
        Args:
            task_text (str): Task text
            
        Returns:
            str: Task category
        """
        task_text_lower = task_text.lower()
        
        for category, data in self.task_categories.items():
            for keyword in data['keywords']:
                if keyword in task_text_lower:
                    return category
        
        return 'general'
    
    def get_first_steps(self, task):
        """
        Get the first steps for a task
        
        Args:
            task (dict): Task dictionary
            
        Returns:
            list: List of first steps
        """
        # If there are subtasks, use them as first steps
        if task['subtasks']:
            incomplete_subtasks = [st for st in task['subtasks'] if not st['completed']]
            if incomplete_subtasks:
                return [st['text'] for st in incomplete_subtasks[:3]]
        
        # Otherwise, generate steps based on task category
        category = self.categorize_task(task['text'])
        
        if category != 'general' and category in self.task_categories:
            return self.task_categories[category]['first_steps']
        
        # Default steps for general category
        return [
            f"{task['text']}の内容を確認する",
            "必要な情報や資料を集める",
            "5分だけ取り組んでみる"
        ]
    
    def break_down_task(self, task):
        """
        Break down a task into smaller, manageable steps
        
        Args:
            task (dict): Task dictionary
            
        Returns:
            list: List of steps
        """
        first_steps = self.get_first_steps(task)
        
        # Add estimated time to each step
        steps_with_time = []
        for step in first_steps:
            # Simple estimation: 5-15 minutes per step
            estimated_time = random.randint(5, 15)
            steps_with_time.append(f"{step} ({estimated_time}分)")
        
        return steps_with_time
    
    def get_priority_tasks(self, count=3):
        """
        Get the top priority tasks
        
        Args:
            count (int): Number of tasks to return
            
        Returns:
            list: List of priority tasks
        """
        if not self.obsidian_connector:
            return []
        
        incomplete_todos = self.obsidian_connector.get_incomplete_todos()
        priority_todos = self.obsidian_connector.get_todos_by_priority(incomplete_todos)
        
        return priority_todos[:count]
    
    def format_task_for_message(self, task):
        """
        Format a task for display in a message
        
        Args:
            task (dict): Task dictionary
            
        Returns:
            dict: Formatted task
        """
        first_steps = self.get_first_steps(task)
        first_step = first_steps[0] if first_steps else "内容を確認する"
        
        return {
            "title": task['text'],
            "first_step": first_step,
            "priority": "高" if task['subtasks'] else "中"
        }
    
    def get_morning_routine(self):
        """
        Get a morning routine to help the user start the day
        
        Returns:
            list: List of morning routine steps
        """
        routine = [
            "ベッドから出て、水を一杯飲む (2分)",
            "カーテンを開けて日光を取り入れる (1分)",
            "深呼吸を3回して、今日の目標を思い浮かべる (1分)"
        ]
        
        # Add the first task if available
        priority_tasks = self.get_priority_tasks(1)
        if priority_tasks:
            task = priority_tasks[0]
            first_steps = self.get_first_steps(task)
            if first_steps:
                routine.append(f"今日の最初のタスク「{task['text']}」に取り掛かる: {first_steps[0]} (10分)")
        
        return routine
    
    def get_next_task_suggestion(self, completed_task=None):
        """
        Get a suggestion for the next task to work on
        
        Args:
            completed_task (dict, optional): Task that was just completed
            
        Returns:
            dict: Next task suggestion
        """
        priority_tasks = self.get_priority_tasks(5)
        
        # Remove the completed task from the list if provided
        if completed_task:
            priority_tasks = [t for t in priority_tasks if t['text'] != completed_task['text']]
        
        if not priority_tasks:
            return None
        
        next_task = priority_tasks[0]
        steps = self.break_down_task(next_task)
        
        return {
            "task": next_task['text'],
            "steps": steps,
            "message": f"お疲れ様でした！次は「{next_task['text']}」に取り組みましょう。"
        }

if __name__ == "__main__":
    # This is for testing
    from obsidian_connector import ObsidianConnector
    
    connector = ObsidianConnector()
    analyzer = TaskAnalyzer(connector)
    
    # Test time-appropriate message
    print(analyzer.get_time_appropriate_message())
    
    # Test task categorization
    test_tasks = [
        "グッチに連絡",
        "スマアカ見積書",
        "obsidian×cursor構築",
        "プラゴミ捨て",
        "ドイツ語"
    ]
    
    for task_text in test_tasks:
        category = analyzer.categorize_task(task_text)
        print(f"Task: {task_text}, Category: {category}")
    
    # Test priority tasks
    priority_tasks = analyzer.get_priority_tasks(3)
    for i, task in enumerate(priority_tasks, 1):
        print(f"{i}. {task['text']}")
        steps = analyzer.break_down_task(task)
        for step in steps:
            print(f"   - {step}")
