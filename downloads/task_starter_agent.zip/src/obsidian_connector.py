#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Obsidian Connector for Task Starter Agent
This module handles the connection to Obsidian and extraction of task data.
"""

import os
import re
import json
import logging
from datetime import datetime
from pathlib import Path

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class ObsidianConnector:
    """
    Class to handle connection to Obsidian and extraction of task data
    """
    
    def __init__(self, vault_path=None):
        """
        Initialize the Obsidian connector
        
        Args:
            vault_path (str): Path to the Obsidian vault
        """
        self.vault_path = vault_path or os.environ.get('OBSIDIAN_VAULT_PATH', '')
        if not self.vault_path:
            logger.warning("Obsidian vault path not set. Using mock data.")
        
        # Ensure vault path exists
        if self.vault_path and not os.path.exists(self.vault_path):
            logger.error(f"Obsidian vault path does not exist: {self.vault_path}")
            self.vault_path = None
    
    def get_todo_files(self):
        """
        Get all markdown files in the vault that might contain TODOs
        
        Returns:
            list: List of file paths
        """
        if not self.vault_path:
            return []
        
        todo_files = []
        for file_path in Path(self.vault_path).glob('**/*.md'):
            # Skip template files or specific directories if needed
            if '/templates/' in str(file_path) or '/.trash/' in str(file_path):
                continue
            todo_files.append(str(file_path))
        
        return todo_files
    
    def extract_todos(self, file_path):
        """
        Extract TODO items from a markdown file
        
        Args:
            file_path (str): Path to the markdown file
            
        Returns:
            list: List of TODO items
        """
        todos = []
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
                
            # Extract TODO items using regex
            # Match both - [ ] and - [x] patterns
            todo_pattern = r'- \[([ x])\] (.*?)(?=\n- \[|$)'
            matches = re.finditer(todo_pattern, content, re.DOTALL)
            
            for match in matches:
                status, text = match.groups()
                completed = status == 'x'
                
                # Clean up the text (remove newlines, etc.)
                text = text.strip().replace('\n', ' ')
                
                # Extract subtasks if any
                subtasks = []
                subtask_pattern = r'    - \[([ x])\] (.*?)(?=\n    - \[|$)'
                subtask_matches = re.finditer(subtask_pattern, content[match.end():], re.DOTALL)
                
                for subtask_match in subtask_matches:
                    subtask_status, subtask_text = subtask_match.groups()
                    subtask_completed = subtask_status == 'x'
                    subtask_text = subtask_text.strip().replace('\n', ' ')
                    
                    subtasks.append({
                        'text': subtask_text,
                        'completed': subtask_completed
                    })
                
                todos.append({
                    'text': text,
                    'completed': completed,
                    'subtasks': subtasks,
                    'file': file_path
                })
        
        except Exception as e:
            logger.error(f"Error extracting TODOs from {file_path}: {e}")
        
        return todos
    
    def get_all_todos(self):
        """
        Get all TODO items from all files in the vault
        
        Returns:
            list: List of all TODO items
        """
        if not self.vault_path:
            # Return mock data for testing
            return self.get_mock_todos()
        
        all_todos = []
        todo_files = self.get_todo_files()
        
        for file_path in todo_files:
            todos = self.extract_todos(file_path)
            all_todos.extend(todos)
        
        return all_todos
    
    def get_mock_todos(self):
        """
        Get mock TODO items for testing
        
        Returns:
            list: List of mock TODO items
        """
        return [
            {
                'text': 'エンペイタスク',
                'completed': False,
                'subtasks': [
                    {'text': 'ディレクトリ構成', 'completed': False},
                    {'text': 'マジポ観点抜き出し', 'completed': False}
                ],
                'file': 'mock_file.md'
            },
            {
                'text': 'スマアカ見積書',
                'completed': False,
                'subtasks': [],
                'file': 'mock_file.md'
            },
            {
                'text': '笹の葉伝助',
                'completed': False,
                'subtasks': [],
                'file': 'mock_file.md'
            },
            {
                'text': '母の郵便',
                'completed': False,
                'subtasks': [],
                'file': 'mock_file.md'
            },
            {
                'text': 'ドイツ語',
                'completed': False,
                'subtasks': [
                    {'text': '日常会話', 'completed': False}
                ],
                'file': 'mock_file.md'
            },
            {
                'text': 'プラゴミ捨て',
                'completed': False,
                'subtasks': [],
                'file': 'mock_file.md'
            },
            {
                'text': '笠原くんホームページ',
                'completed': False,
                'subtasks': [],
                'file': 'mock_file.md'
            },
            {
                'text': 'グッチに連絡',
                'completed': False,
                'subtasks': [],
                'file': 'mock_file.md'
            },
            {
                'text': 'obsidian×cursor構築',
                'completed': False,
                'subtasks': [
                    {'text': 'Manusでやる', 'completed': True},
                    {'text': 'cursorでまとめるフロー構築', 'completed': False}
                ],
                'file': 'mock_file.md'
            }
        ]
    
    def get_incomplete_todos(self):
        """
        Get all incomplete TODO items
        
        Returns:
            list: List of incomplete TODO items
        """
        all_todos = self.get_all_todos()
        return [todo for todo in all_todos if not todo['completed']]
    
    def get_todos_by_priority(self, todos=None):
        """
        Get TODO items sorted by priority
        
        Args:
            todos (list, optional): List of TODO items to sort. If None, get all incomplete TODOs.
            
        Returns:
            list: List of TODO items sorted by priority
        """
        if todos is None:
            todos = self.get_incomplete_todos()
        
        # Simple priority algorithm:
        # 1. Items with subtasks are higher priority
        # 2. Items with fewer subtasks are easier to complete
        # 3. Items at the top of the list are higher priority
        
        # Sort by number of subtasks (fewer first) and then by position in the list
        return sorted(todos, key=lambda x: (0 if x['subtasks'] else 1, len(x['subtasks'])))
    
    def get_first_steps(self, todo):
        """
        Get the first steps for a TODO item
        
        Args:
            todo (dict): TODO item
            
        Returns:
            list: List of first steps
        """
        steps = []
        
        # If there are subtasks, use the first incomplete subtask
        if todo['subtasks']:
            incomplete_subtasks = [st for st in todo['subtasks'] if not st['completed']]
            if incomplete_subtasks:
                steps.append(incomplete_subtasks[0]['text'])
            else:
                steps.append("すべてのサブタスクが完了しています。次のステップを検討しましょう。")
        else:
            # Generate a first step based on the task name
            task_text = todo['text'].lower()
            
            if '連絡' in task_text or 'メール' in task_text or '電話' in task_text:
                steps.append("連絡する相手と内容を確認する")
            elif '書' in task_text or 'レポート' in task_text or '文書' in task_text:
                steps.append("必要な情報を集める")
            elif '構築' in task_text or '開発' in task_text or 'アプリ' in task_text:
                steps.append("要件を整理する")
            elif '買い物' in task_text or '購入' in task_text:
                steps.append("必要なものリストを作成する")
            elif '掃除' in task_text or '片付け' in task_text:
                steps.append("5分だけ始めてみる")
            else:
                steps.append(f"{todo['text']}の内容を確認する")
        
        return steps

if __name__ == "__main__":
    # This is for testing
    connector = ObsidianConnector()
    todos = connector.get_incomplete_todos()
    for todo in todos[:5]:  # Show first 5 todos
        print(f"Task: {todo['text']}")
        print(f"Completed: {todo['completed']}")
        print(f"Subtasks: {len(todo['subtasks'])}")
        print(f"First steps: {connector.get_first_steps(todo)}")
        print("---")
