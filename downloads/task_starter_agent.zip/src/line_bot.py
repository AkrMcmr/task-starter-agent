#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LINE Bot for Task Starter Agent
This module handles the LINE messaging functionality for the task starter agent.
"""

import os
import json
import logging
from datetime import datetime
from flask import Flask, request, abort
from linebot import LineBotApi, WebhookHandler
from linebot.exceptions import InvalidSignatureError
from linebot.models import (
    MessageEvent, TextMessage, TextSendMessage,
    FlexSendMessage, BubbleContainer, BoxComponent,
    TextComponent, ButtonComponent, ActionComponent,
    URIAction, MessageAction
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)

# LINE API credentials (to be set as environment variables)
LINE_CHANNEL_ACCESS_TOKEN = os.environ.get('LINE_CHANNEL_ACCESS_TOKEN', '')
LINE_CHANNEL_SECRET = os.environ.get('LINE_CHANNEL_SECRET', '')

# Initialize LINE API
line_bot_api = LineBotApi(LINE_CHANNEL_ACCESS_TOKEN)
handler = WebhookHandler(LINE_CHANNEL_SECRET)

# Import task modules (to be implemented)
from task_analyzer import TaskAnalyzer
from obsidian_connector import ObsidianConnector

# Initialize task modules
task_analyzer = None
obsidian_connector = None

@app.route("/callback", methods=['POST'])
def callback():
    """
    LINE Webhook callback endpoint
    """
    # Get X-Line-Signature header value
    signature = request.headers['X-Line-Signature']

    # Get request body as text
    body = request.get_data(as_text=True)
    logger.info("Request body: %s", body)

    # Handle webhook body
    try:
        handler.handle(body, signature)
    except InvalidSignatureError:
        logger.error("Invalid signature. Check your channel secret.")
        abort(400)

    return 'OK'

@handler.add(MessageEvent, message=TextMessage)
def handle_message(event):
    """
    Handle incoming messages from users
    """
    user_id = event.source.user_id
    text = event.message.text
    
    # Process user message
    if text == "今日のタスク":
        send_today_tasks(user_id)
    elif text == "次のステップ":
        send_next_steps(user_id)
    elif text == "朝の準備":
        send_morning_routine(user_id)
    elif text == "ヘルプ":
        send_help_message(user_id)
    else:
        # Default response
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text="こんにちは！「今日のタスク」「次のステップ」「朝の準備」などと入力してみてください。")
        )

def send_today_tasks(user_id):
    """
    Send today's tasks to the user
    """
    # This will be implemented to fetch tasks from Obsidian
    # For now, we'll use a placeholder
    tasks = [
        {"title": "エンペイタスク", "first_step": "ディレクトリ構成を確認する", "priority": "高"},
        {"title": "スマアカ見積書", "first_step": "必要な情報を集める", "priority": "中"},
        {"title": "笹の葉伝助", "first_step": "前回の進捗を確認する", "priority": "低"}
    ]
    
    # Create a Flex message
    flex_message = create_task_list_flex(tasks)
    
    # Send the message
    line_bot_api.push_message(
        user_id,
        FlexSendMessage(
            alt_text="今日のタスク",
            contents=flex_message
        )
    )

def send_next_steps(user_id):
    """
    Send the next steps for the current task
    """
    # This will be implemented to analyze and suggest next steps
    # For now, we'll use a placeholder
    steps = [
        "1. ディレクトリ構成を確認する (5分)",
        "2. マジポ観点を抜き出す (10分)",
        "3. 結果をまとめる (5分)"
    ]
    
    message = "【エンペイタスク】の次のステップ:\n\n" + "\n".join(steps) + "\n\n完了したら「次のタスク」と送ってください。"
    
    line_bot_api.push_message(
        user_id,
        TextSendMessage(text=message)
    )

def send_morning_routine(user_id):
    """
    Send morning routine message to help user start the day
    """
    current_time = datetime.now().strftime("%H:%M")
    
    message = f"""おはようございます！現在時刻は{current_time}です。

今日も素晴らしい一日にしましょう！まずは以下のステップから始めてみませんか？

1. ベッドから出て、水を一杯飲む (2分)
2. カーテンを開けて日光を取り入れる (1分)
3. 今日の最初のタスク「エンペイタスク」に取り掛かる (20分)

準備ができたら「今日のタスク」と送ってください。"""
    
    line_bot_api.push_message(
        user_id,
        TextSendMessage(text=message)
    )

def send_help_message(user_id):
    """
    Send help message explaining how to use the bot
    """
    message = """【タスク開始支援エージェントの使い方】

以下のコマンドが利用できます：

・「今日のタスク」- 今日取り組むべきタスクの一覧を表示
・「次のステップ」- 現在のタスクの次のステップを表示
・「朝の準備」- 朝の準備ルーティンを表示
・「ヘルプ」- このヘルプメッセージを表示

朝、昼休み明け、夜寝る前に自動的にメッセージをお送りします。"""
    
    line_bot_api.push_message(
        user_id,
        TextSendMessage(text=message)
    )

def create_task_list_flex(tasks):
    """
    Create a Flex message for task list
    """
    # This is a simplified version, will be enhanced later
    contents = {
        "type": "bubble",
        "header": {
            "type": "box",
            "layout": "vertical",
            "contents": [
                {
                    "type": "text",
                    "text": "今日のタスク",
                    "weight": "bold",
                    "size": "xl",
                    "color": "#ffffff"
                }
            ],
            "backgroundColor": "#27ACB2"
        },
        "body": {
            "type": "box",
            "layout": "vertical",
            "contents": []
        },
        "footer": {
            "type": "box",
            "layout": "vertical",
            "contents": [
                {
                    "type": "button",
                    "action": {
                        "type": "message",
                        "label": "次のステップを見る",
                        "text": "次のステップ"
                    },
                    "style": "primary",
                    "color": "#27ACB2"
                }
            ]
        }
    }
    
    # Add tasks to the body
    for task in tasks:
        task_box = {
            "type": "box",
            "layout": "vertical",
            "margin": "lg",
            "contents": [
                {
                    "type": "text",
                    "text": task["title"],
                    "weight": "bold",
                    "size": "md"
                },
                {
                    "type": "text",
                    "text": f"最初のステップ: {task['first_step']}",
                    "size": "sm",
                    "wrap": True,
                    "margin": "sm"
                },
                {
                    "type": "text",
                    "text": f"優先度: {task['priority']}",
                    "size": "xs",
                    "color": "#aaaaaa",
                    "margin": "sm"
                }
            ]
        }
        contents["body"]["contents"].append(task_box)
        
        # Add separator except for the last item
        if task != tasks[-1]:
            contents["body"]["contents"].append({
                "type": "separator",
                "margin": "lg"
            })
    
    return contents

def schedule_notifications():
    """
    Schedule notifications for morning, afternoon, and evening
    This will be implemented with a proper scheduler
    """
    pass

if __name__ == "__main__":
    # This is for local testing
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port)
