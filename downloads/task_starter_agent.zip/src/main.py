#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Main application for Task Starter Agent
This module integrates all components and provides the main entry point.
"""

import os
import sys
import logging
import threading
import time
from flask import Flask, request, abort
from linebot import LineBotApi, WebhookHandler
from linebot.exceptions import InvalidSignatureError
from linebot.models import (
    MessageEvent, TextMessage, TextSendMessage,
    FlexSendMessage, BubbleContainer
)

# Add the current directory to the path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Import local modules
from obsidian_connector import ObsidianConnector
from task_analyzer import TaskAnalyzer
from task_scheduler import TaskScheduler

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("task_starter.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)

# LINE API credentials
LINE_CHANNEL_ACCESS_TOKEN = os.environ.get('LINE_CHANNEL_ACCESS_TOKEN', '')
LINE_CHANNEL_SECRET = os.environ.get('LINE_CHANNEL_SECRET', '')

# Obsidian vault path
OBSIDIAN_VAULT_PATH = os.environ.get('OBSIDIAN_VAULT_PATH', '')

# Initialize LINE API
line_bot_api = LineBotApi(LINE_CHANNEL_ACCESS_TOKEN)
handler = WebhookHandler(LINE_CHANNEL_SECRET)

# Initialize components
obsidian_connector = ObsidianConnector(OBSIDIAN_VAULT_PATH)
task_analyzer = TaskAnalyzer(obsidian_connector)
scheduler = TaskScheduler(line_bot_api, task_analyzer, obsidian_connector)

# Set notification times
MORNING_TIME = os.environ.get('MORNING_TIME', '07:00')
AFTERNOON_TIME = os.environ.get('AFTERNOON_TIME', '13:00')
EVENING_TIME = os.environ.get('EVENING_TIME', '22:00')
scheduler.set_notification_times(MORNING_TIME, AFTERNOON_TIME, EVENING_TIME)

@app.route("/callback", methods=['POST'])
def callback():
    """
    LINE Webhook callback endpoint
    """
    # Get X-Line-Signature header value
    signature = request.headers['X-Line-Signature']

    # Get request body as text
    body = request.get_data(as_text=True)
    logger.info("Request body: %s", body)

    # Handle webhook body
    try:
        handler.handle(body, signature)
    except InvalidSignatureError:
        logger.error("Invalid signature. Check your channel secret.")
        abort(400)

    return 'OK'

@handler.add(MessageEvent, message=TextMessage)
def handle_message(event):
    """
    Handle incoming messages from users
    """
    user_id = event.source.user_id
    text = event.message.text
    
    # Add user to notification list
    scheduler.add_user_id(user_id)
    
    # Process user message
    if text == "今日のタスク":
        send_today_tasks(event.reply_token, user_id)
    elif text == "次のステップ":
        send_next_steps(event.reply_token, user_id)
    elif text == "朝の準備":
        send_morning_routine(event.reply_token, user_id)
    elif text == "ヘルプ":
        send_help_message(event.reply_token)
    else:
        # Default response
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text="こんにちは！「今日のタスク」「次のステップ」「朝の準備」などと入力してみてください。")
        )

def send_today_tasks(reply_token, user_id):
    """
    Send today's tasks to the user
    """
    # Get priority tasks
    priority_tasks = task_analyzer.get_priority_tasks(5)
    
    # Format tasks for display
    formatted_tasks = []
    for task in priority_tasks:
        formatted_task = task_analyzer.format_task_for_message(task)
        formatted_tasks.append(formatted_task)
    
    if not formatted_tasks:
        line_bot_api.reply_message(
            reply_token,
            TextSendMessage(text="タスクが見つかりませんでした。Obsidianのデータを確認してください。")
        )
        return
    
    # Create a Flex message
    from line_bot import create_task_list_flex
    flex_message = create_task_list_flex(formatted_tasks)
    
    # Send the message
    line_bot_api.reply_message(
        reply_token,
        FlexSendMessage(
            alt_text="今日のタスク",
            contents=flex_message
        )
    )

def send_next_steps(reply_token, user_id):
    """
    Send the next steps for the current task
    """
    # Get priority tasks
    priority_tasks = task_analyzer.get_priority_tasks(1)
    
    if not priority_tasks:
        line_bot_api.reply_message(
            reply_token,
            TextSendMessage(text="タスクが見つかりませんでした。Obsidianのデータを確認してください。")
        )
        return
    
    task = priority_tasks[0]
    steps = task_analyzer.break_down_task(task)
    
    message = f"【{task['text']}】の次のステップ:\n\n"
    for i, step in enumerate(steps, 1):
        message += f"{i}. {step}\n"
    
    message += "\n完了したら「次のタスク」と送ってください。"
    
    line_bot_api.reply_message(
        reply_token,
        TextSendMessage(text=message)
    )

def send_morning_routine(reply_token, user_id):
    """
    Send morning routine message to help user start the day
    """
    routine = task_analyzer.get_morning_routine()
    
    message = task_analyzer.get_time_appropriate_message() + "\n\n"
    message += "今日も素晴らしい一日にしましょう！まずは以下のステップから始めてみませんか？\n\n"
    
    for i, step in enumerate(routine, 1):
        message += f"{i}. {step}\n"
    
    message += "\n準備ができたら「今日のタスク」と送ってください。"
    
    line_bot_api.reply_message(
        reply_token,
        TextSendMessage(text=message)
    )

def send_help_message(reply_token):
    """
    Send help message explaining how to use the bot
    """
    message = """【タスク開始支援エージェントの使い方】

以下のコマンドが利用できます：

・「今日のタスク」- 今日取り組むべきタスクの一覧を表示
・「次のステップ」- 現在のタスクの次のステップを表示
・「朝の準備」- 朝の準備ルーティンを表示
・「ヘルプ」- このヘルプメッセージを表示

朝、昼休み明け、夜寝る前に自動的にメッセージをお送りします。"""
    
    line_bot_api.reply_message(
        reply_token,
        TextSendMessage(text=message)
    )

def start_scheduler():
    """
    Start the scheduler in a separate thread
    """
    scheduler.run_scheduler()

def main():
    """
    Main entry point
    """
    logger.info("Starting Task Starter Agent")
    
    # Start scheduler in a separate thread
    scheduler_thread = threading.Thread(target=start_scheduler)
    scheduler_thread.daemon = True
    scheduler_thread.start()
    
    # Start Flask app
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port)

if __name__ == "__main__":
    main()
